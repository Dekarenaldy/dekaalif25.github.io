define({
  "_themeLabel": "Тема \"Билборд\"",
  "_layout_default": "Оформление по подразбиране",
  "_layout_right": "Дясно оформление"
});