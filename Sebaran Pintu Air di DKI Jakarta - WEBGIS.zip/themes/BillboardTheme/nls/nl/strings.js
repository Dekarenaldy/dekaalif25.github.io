define({
  "_themeLabel": "Billboard-thema",
  "_layout_default": "Standaardlay-out",
  "_layout_right": "Juiste lay-out"
});