define({
  "_themeLabel": "Motív Billboard",
  "_layout_default": "Predvolené rozloženie",
  "_layout_right": "Rozloženie vpravo"
});