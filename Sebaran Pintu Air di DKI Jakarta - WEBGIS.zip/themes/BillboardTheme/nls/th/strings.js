define({
  "_themeLabel": "บิลบอร์ดธีม",
  "_layout_default": "เค้าโครงเริ่มต้น",
  "_layout_right": "รูปแบบที่เหมาะสม"
});