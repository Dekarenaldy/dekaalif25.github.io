define({
  "_themeLabel": "Temă panou publicitar",
  "_layout_default": "Aspect implicit",
  "_layout_right": "Aspect corect"
});